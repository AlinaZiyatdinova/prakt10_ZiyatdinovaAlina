interface Opletka {
    var avability: Int
}