import ClassMain
class Cabel: ClassMain() {
    override var type = " "
    override var countjil = 0
    override var diametr = 0.0
    override var avability = 0
    override fun Q(): Double {
        var q: Double = 0.0
        q = diametr / countjil
        return q
    }
    override fun Qr(): Double {
        var qr:Double = 0.0
        if (avability == 1)
        {
            qr = 2*Q()
        }
        else
        {
            qr = 0.7*Q()
        }
        return qr
    }
    override fun output() {
        println("Тип кабеля: ${type}\nКоличество жил: ${countjil}\nДиаметр: ${diametr}\nНаличие оплетки: ${avability}\nQ: ${Q()}\nQr: ${Qr()}\n")
    }
}