fun main()
{
    var cabel1 = Cabel()
    cabel1.entry()
    var q = cabel1.Q()
    var qr = cabel1.Qr()
    cabel1.output()
}