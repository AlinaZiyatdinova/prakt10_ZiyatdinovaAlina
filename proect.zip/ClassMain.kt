abstract class ClassMain: Interface {
    fun entry()
    {
        while (true) {
            try {
                println("Введите тип кабеля:")
                type = readLine()!!.toString()
                while (type.length <= 0)
                {
                    println("Повотрите ввод. Введите тип кабеля.")
                    type = readLine()!!.toString()
                }
                println("Введите диаметр:")
                diametr = readLine()!!.toDouble()
                while (diametr<0)
                {
                    println("Диаметр может быть меньше нуля. Повотрите ввод.")
                    diametr = readLine()!!.toDouble()
                }
                println("Введите количество жил:")
                countjil = readLine()!!.toInt()
                while (countjil<0)
                {
                    println("Количество жил не может быть меньше нуля. Повотрите ввод.")
                    countjil = readLine()!!.toInt()
                }
                println("Есть оплетка? Введите 1- да, 2-нет:")
                avability = readLine()!!.toInt()
                while (avability!=1 && avability!=2)
                {
                    println("Введите 1 или 2.")
                    avability = readLine()!!.toInt()
                }
                break
            }
            catch (e:Exception)
            {
                println("Возникло исключение! Повторите ввод.")
            }
        }
    }
}