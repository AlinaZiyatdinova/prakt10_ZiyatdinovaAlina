import ex1.MainClass
fun main()
{
    var cabel1 = MainClass()
    while (true) {
        try {
            println("Введите тип кабеля:")
            cabel1.type = readLine()!!.toString()
            while (cabel1.type.length <= 0)
            {
                println("Повотрите ввод. Введите тип кабеля.")
                cabel1.type = readLine()!!.toString()
            }
            println("Введите диаметр:")
            cabel1.diametr = readLine()!!.toDouble()
            while (cabel1.diametr<0)
            {
                println("Диаметр может быть меньше нуля. Повотрите ввод.")
                cabel1.diametr = readLine()!!.toDouble()
            }
            println("Введите количество жил:")
            cabel1.countjil = readLine()!!.toInt()
            while (cabel1.countjil<0)
            {
                println("Количество жил не может быть меньше нуля. Повотрите ввод.")
                cabel1.countjil = readLine()!!.toInt()
            }
            println("Есть оплетка? Введите 1- да, 2-нет:")
            cabel1.avability = readLine()!!.toInt()
            while (cabel1.avability!=1 && cabel1.avability!=2)
            {
                println("Введите 1 или 2.")
                cabel1.avability = readLine()!!.toInt()
            }
            break
    }
        catch (e:Exception)
        {
            println("Возникло исключение! Повторите ввод.")
        }
    }
        var q = cabel1.Q()
        var qr = cabel1.Qr()
        cabel1.output()
}