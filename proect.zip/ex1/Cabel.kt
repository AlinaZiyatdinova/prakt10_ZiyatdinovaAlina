package ex1

abstract class Cabel: Opletka(){
    abstract var type: String
    abstract var countjil:Int
    abstract var diametr: Double
    abstract fun Q():Double
    abstract fun Qr():Double
    abstract fun output()
}