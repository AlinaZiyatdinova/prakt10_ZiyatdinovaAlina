package ex1

abstract class Opletka {
    abstract var avability: Int
}