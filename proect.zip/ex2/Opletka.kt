package ex2
interface Opletka{
var avability: Int
}