package ex2
interface Cabel: Opletka{
    var type: String
    var countjil:Int
    var diametr: Double
    fun Q():Double
    fun Qr():Double
    fun output()
}