interface Interface: Opletka {
     var type: String
     var countjil:Int
     var diametr: Double
     fun Q():Double
     fun Qr():Double
     fun output()

}